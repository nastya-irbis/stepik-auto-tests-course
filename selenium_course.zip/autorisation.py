import time

from selenium import webdriver

link = "https://test.red-circule.com/"
browser = webdriver.Chrome()
browser.get(link)

button = browser.find_element_by_css_selector("button.signIn--1-3827159394")
button.click()

time.sleep(3)

input1 = browser.find_element_by_css_selector("input[type='email']")
input1.send_keys("nastik.test@gmail.com")

input2 = browser.find_element_by_css_selector("input[type='password']")
input2.send_keys("1q2w3e4r")

button_voity = browser.find_element_by_css_selector("input[type='submit']")
button_voity.click()

time.sleep(5)

lk_link = browser.find_element_by_css_selector("a.dropdownButton--1-298640448")
#lk_link = browser.find_element_by_link_text("Личный кабинет")
lk_text = lk_link.text
#print(lk_text)
assert "ЛИЧНЫЙ КАБИНЕТ" == lk_text

time.sleep(10)
browser.quit()
