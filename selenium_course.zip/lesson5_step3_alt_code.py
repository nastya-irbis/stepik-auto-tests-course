import time
from selenium import webdriver
 

def working():
    options = webdriver.ChromeOptions()
    driver = webdriver.Chrome(executable_path=r"C:\chromedriver.exe")

    driver.get('http://suninjuly.github.io/simple_form_find_task.html')


    try:
        input1 = driver.find_element_by_name('first_name')
        input1.send_keys("Ivan")
        input2 = driver.find_element_by_name('last_name')
        input2.send_keys("Petrov")
        input3 = driver.find_element_by_xpath('//input[@class="form-control city"]')
        input3.send_keys("Smolensk")
        input4 = driver.find_element_by_id('country')
        input4.send_keys("Russia")
        button = driver.find_element_by_css_selector("button.btn")
        button.click()
        time.sleep(100)


    except Exception as errors:
        print(f'Ошибка в глобальном скоупе | {errors}')

    finally:
        driver.close()
        sleep(2)
        driver.quit()



working()