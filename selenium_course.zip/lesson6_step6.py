import math
from selenium import webdriver
import time

link = "http://suninjuly.github.io/math.html"
browser = webdriver.Chrome()
browser.get(link)

robots_radio = browser.find_element_by_id("robotCheckbox")
#robots_radio.click()
robots_checked = robots_radio.get_attribute("checked")
print(type(robots_checked))
#assert robots_checked is None 


time.sleep(10)
browser.quit()